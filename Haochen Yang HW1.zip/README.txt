The resource I used for this project are most from the lecture and section materials.
I learn how to change the text color in this website:
	https://www.tutorialkart.com/kotlin-android/android-textview-text-color/#:~:text=Change%20Text%20Color%20of%20TextView%20in%20Kotlin%20File,specific%20color%20passed%20as%20argument.
And the change the text in this website:
https://stackoverflow.com/questions/44096838/kotlin-how-to-get-and-set-a-text-to-textview-in-android-using-kotlin/48188102
